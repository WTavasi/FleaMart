package Deliveries;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import Customer.CustomerDashboard;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Deliveries page for the application.
 */
public class Deliveries extends javax.swing.JFrame {

    public Deliveries() {
        initComponents();
    }

    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnBack = new javax.swing.JButton();
        btnConfirmDelivery = new javax.swing.JButton();
        btnAddDelivery = new javax.swing.JButton(); // New button for adding deliveries

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 51, 102));
        jPanel1.setLayout(new java.awt.GridBagLayout());

        jLabel1.setFont(new java.awt.Font("Constantia", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Delivery Information");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(20, 0, 20, 0);
        jPanel1.add(jLabel1, gridBagConstraints);

        jTable1.setModel(new DefaultTableModel(
                new Object[][]{
                        {false, 1, "Order1", "Shipped", "12/07/2023"},
                        {false, 2, "Order2", "In Transit", "13/07/2023"},
                        {false, 3, "Order3", "Delivered", "10/07/2023"},
                        {false, 4, "Order4", "Pending", "15/07/2023"}
                },
                new String[]{
                        "Select", "Delivery ID", "Order", "Status", "Delivery Date"
                }
        ) {
            @SuppressWarnings("rawtypes")
            Class[] types = new Class[]{
                    java.lang.Boolean.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            @SuppressWarnings({ "rawtypes", "unchecked" })
            public Class getColumnClass(int columnIndex) {
                return types[columnIndex];
            }

            public boolean isCellEditable(int row, int column) {
                return column == 0; // Only the first column is editable (checkboxes)
            }
        });
        jScrollPane1.setViewportView(jTable1);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 20, 20);
        jPanel1.add(jScrollPane1, gridBagConstraints);

        btnBack.setFont(new java.awt.Font("Gadugi", 1, 14)); // NOI18N
        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 0);
        jPanel1.add(btnBack, gridBagConstraints);

        btnConfirmDelivery.setFont(new java.awt.Font("Gadugi", 1, 14)); // NOI18N
        btnConfirmDelivery.setText("Confirm Delivery");
        btnConfirmDelivery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmDeliveryActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 20, 0);
        jPanel1.add(btnConfirmDelivery, gridBagConstraints);

        // New button for adding deliveries
        btnAddDelivery.setFont(new java.awt.Font("Gadugi", 1, 14));
        btnAddDelivery.setText("Add Delivery");
        btnAddDelivery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddDeliveryActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 0);
        jPanel1.add(btnAddDelivery, gridBagConstraints);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );

        pack();
    }

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {
        // Close the current window
        this.dispose();

        // Show the customer dashboard (Login page)
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerDashboard().setVisible(true);
            }
        });
    }

    private void btnConfirmDeliveryActionPerformed(java.awt.event.ActionEvent evt) {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        StringBuilder selectedOrders = new StringBuilder();
        for (int i = 0; i < model.getRowCount(); i++) {
            Boolean isSelected = (Boolean) model.getValueAt(i, 0);
            if (isSelected) {
                selectedOrders.append("Order ID: ").append(model.getValueAt(i, 1)).append("\n");
            }
        }
        if (selectedOrders.length() > 0) {
            JOptionPane.showMessageDialog(this, "Selected orders for delivery:\n" + selectedOrders.toString());
        } else {
            JOptionPane.showMessageDialog(this, "No orders selected for delivery.");
        }
    }

    private void btnAddDeliveryActionPerformed(java.awt.event.ActionEvent evt) {
        // Create and show the dialog for adding a new delivery
        AddDeliveryDialog dialog = new AddDeliveryDialog(this, true);
        dialog.setVisible(true);

        // After dialog closes, update the table with new delivery information if needed
        // For simplicity, assume updating jTable1 with new data
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Deliveries().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnConfirmDelivery;
    private javax.swing.JButton btnAddDelivery;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration

    // Inner class for adding delivery dialog
    private class AddDeliveryDialog extends JDialog {

        private JTextField txtRecipientName;
        private JTextField txtAddress;
        private JTextField txtItem;

        public AddDeliveryDialog(Frame parent, boolean modal) {
            super(parent, modal);
            initComponents();
        }

        private void initComponents() {
            setTitle("Add Delivery");
            setSize(400, 300);
            setLocationRelativeTo(null);
            setLayout(new GridLayout(4, 2));

            add(new JLabel("Recipient Name:"));
            txtRecipientName = new JTextField();
            add(txtRecipientName);

            add(new JLabel("Address:"));
            txtAddress = new JTextField();
            add(txtAddress);

            add(new JLabel("Item:"));
            txtItem = new JTextField();
            add(txtItem);

            JButton btnAdd = new JButton("Add");
            btnAdd.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String recipientName = txtRecipientName.getText();
                    String address = txtAddress.getText();
                    String item = txtItem.getText();

                    // Validate input (for simplicity, assume all fields are required)
                    if (recipientName.isEmpty() || address.isEmpty() || item.isEmpty()) {
                        JOptionPane.showMessageDialog(AddDeliveryDialog.this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Add new delivery information to jTable1
                    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                    model.addRow(new Object[]{false, model.getRowCount() + 1, item, "Pending", "Now"});

                    // Close the dialog
                    dispose();
                }
            });
            add(btnAdd);

            JButton btnCancel = new JButton("Cancel");
            btnCancel.addActionListener((ActionListener) new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Close the dialog
                    dispose();
                }
            });
            add(btnCancel);
        }
    }
}
