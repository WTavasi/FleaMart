package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;

/**
 *
 * @author wtwas
 */
public class MyConnection {

    public static Connection getConnection() {
        Connection conn = null;
        Statement stmt;
        ResultSet rs;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/myConnection";
            String uName = "root";
            String uPass = "";

            conn = DriverManager.getConnection(url, uName, uPass);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

            String SQL = "Select * from user, admin, category, product, purchase, supplier";
            rs = stmt.executeQuery(SQL);
            if(rs.next()){
                System.out.println("Database Connection Successful!");
            }

        } catch (SQLException | java.lang.ClassNotFoundException e) {
            System.err.print("ClassNotFoundException: ");
            System.err.println(e.getMessage());
        }
        return conn;
    }
    public static void main(String[] args) {
        Connection connection = MyConnection.getConnection();
        if (connection != null) {
            System.out.println("Connection established successfully.");
        } else {
            System.out.println("Failed to establish connection.");
        }
    }
}
